<?php

namespace App\Exceptions;

use Exception;

class LimitExceededException extends Exception
{
}
