<?php

namespace App\Exceptions;

use Exception;

class BasicException extends Exception
{
}
