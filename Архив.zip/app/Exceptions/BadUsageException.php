<?php

namespace App\Exceptions;

use Exception;

class BadUsageException extends Exception
{
}
