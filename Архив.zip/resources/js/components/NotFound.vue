<script>
export default {
    name: "NotFound"
}
</script>

<template>
  <div>
      <h1>Страница не найдена</h1>
      <p>Извините, запрашиваемая страница не существует.</p>
  </div>
</template>

<style scoped lang="sass">

</style>
